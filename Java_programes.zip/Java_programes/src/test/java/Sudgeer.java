public class Sudgeer {
    public static void main(String[] args) {
        int i=100;
        int j=120;

        if (i>j){
            System.out.println("i>j");
        }
        else if (i<j){
            System.out.println("i<j");
        }
        else if (i==j){
            System.out.println("i==j");
        }
    }
}
