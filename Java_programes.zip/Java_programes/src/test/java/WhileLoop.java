public class WhileLoop {
    public static void main(String[] args) {
        int a = 50;
        while (a < 100) {
            System.out.println("the value of:"+a);
            a++;
            System.out.println("\n");

        }
    }
}