public class DataTypes {
    public static void main(String[] args) {
        //primitive datatypes
        int myInt=854654444;
        Short sht=32767;
        boolean bool=true;
        //for boolean we can use the keyboard like true or false
        long lng=4685465L;
        byte bt=-127+130;

        float myfloat=2.2555f;
        double mydouble=2.654d;
        char ch='c';
        //to create an object the syntax is
        //classname obj(or)variable=new classname():
        DataTypes primitive=new DataTypes();
        String str=new String();
        String str1="this is basic";
        String str2="new";


    }
}
