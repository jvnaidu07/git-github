public class VariablesDemo {
    //int j =20; //instance variable
    public static void main(String[] args) {
        //type variablename= value;
        int mynumber = 10;
        int secondNumber=20;
        char ch='a';
        String str="RCV";
        System.out.println(str+" "+mynumber+" "+ch+" "+secondNumber);
        System.out.println(mynumber+secondNumber);

    }
    //How to create a method
    public void myMethod(){
        int i =20;

    }
}
